//
//  ViewControllerColor.swift
//  Tarea 2
//
//  Created by Alumno on 01/09/22.
//

import UIKit

class ViewControllerColor: UIViewController {
    
    @IBOutlet weak var redBtn: UIButton!
    @IBOutlet weak var blueBtn: UIButton!
    @IBOutlet weak var greenBtn: UIButton!
    @IBOutlet weak var yellowBtn: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func red(_ sender: Any) {
        let vistaIni = presentingViewController as! ViewController
        vistaIni.actualizaColor(color: UIColor.red)
        dismiss(animated: true)
    }
    
    @IBAction func blue(_ sender: Any) {
        let vistaIni = presentingViewController as! ViewController
        vistaIni.actualizaColor(color: UIColor.blue)
        dismiss(animated: true)
    }
    
    @IBAction func green(_ sender: Any) {
        let vistaIni = presentingViewController as! ViewController
        vistaIni.actualizaColor(color: UIColor.green)
        dismiss(animated: true)
    }
    
    @IBAction func yellow(_ sender: Any) {
        let vistaIni = presentingViewController as! ViewController
        vistaIni.actualizaColor(color: UIColor.yellow)
        dismiss(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
