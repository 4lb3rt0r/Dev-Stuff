//
//  ViewController.swift
//  Tarea 2
//
//  Created by Alumno on 01/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imgFoto: UIImageView!
    @IBOutlet weak var tfMessage: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func actualizaMensaje(mensaje: String) {
        tfMessage.text = mensaje
    }
    
    func actualizaColor(color: UIColor) {
        view.backgroundColor = color
    }
    
    func actualizaFoto(foto: UIImage) {
        imgFoto.image = foto
    }
    
   override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       if segue.identifier == "Mes" {
           let vistaMensaje = segue.destination as! ViewControllerMessage
       vistaMensaje.mes = tfMessage.text!
       }

    }
    


}

