//
//  ViewControllerPhoto.swift
//  Tarea 2
//
//  Created by Alumno on 01/09/22.
//

import UIKit

class ViewControllerPhoto: UIViewController {
    
    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img3: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func imagen1(_ sender: Any) {
        let vistaIni = presentingViewController as! ViewController
        vistaIni.actualizaFoto(foto: img1.image!)
        dismiss(animated: true)
    }
    
    @IBAction func imagen2(_ sender: Any) {
        let vistaIni = presentingViewController as! ViewController
        vistaIni.actualizaFoto(foto: img2.image!)
        dismiss(animated: true)
    }
    
    @IBAction func imagen3(_ sender: Any) {
        let vistaIni = presentingViewController as! ViewController
        vistaIni.actualizaFoto(foto: img3.image!)
        dismiss(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
