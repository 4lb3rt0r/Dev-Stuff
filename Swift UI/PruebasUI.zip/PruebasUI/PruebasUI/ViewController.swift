//
//  ViewController.swift
//  PruebasUI
//
//  Created by Alumno on 03/10/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lbMensaje: UILabel!
    @IBOutlet weak var tfUsuario: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    
    var fakeUser = "usuario"
    var fakePassword = "1234"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func cambioSegmented(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            lbMensaje.text = "Rojo"
        }
        else {
            lbMensaje.text = "Verde"
        }
    }
    
    @IBAction func quitaTeclado(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    
    @IBAction func btnLogin(_ sender: Any) {
        if tfUsuario.text == fakeUser && tfPassword.text == fakePassword {
            performSegue(withIdentifier: "vista2", sender: self)
        }
        else {
            let alerta = UIAlertController(title: "Error", message: "Usuario o password incorrectos", preferredStyle: .alert)
            let accion = UIAlertAction(title: "OK", style: .cancel)
            alerta.addAction(accion)
            present(alerta, animated: true)
        }
    }
    
    
}

