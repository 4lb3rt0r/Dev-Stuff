//
//  ViewController.swift
//  cargoDatos
//
//  Created by Alumno on 08/09/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    

    @IBOutlet weak var tlTipo: UILabel!
    @IBOutlet weak var tlCapacidad: UILabel!
    @IBOutlet weak var tlPrecio: UILabel!
    @IBOutlet weak var imgFoto: UIImageView!
    
    
    var listaDispositivos = [Dispositivo]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cargarDatosPList()
    }
    
    func rutaPlist() -> String {
        if let ruta = Bundle.main.path(forResource: "Property List", ofType: "plist") {
            return ruta
        }
        return ""
    }

    func cargarDatosPList() {
        do {
            let data = try Data.init(contentsOf: URL(fileURLWithPath: rutaPlist()))
            listaDispositivos = try
            PropertyListDecoder().decode([Dispositivo].self, from: data)
        } catch {
            print("Error al cargar el Archivo")
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Cuantas rows son
        return listaDispositivos.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let urli = try? Data(contentsOf: URL(string: listaDispositivos[indexPath.row].urlFoto)!)
        imgFoto.image = UIImage(data: urli!)
        tlTipo.text = listaDispositivos[indexPath.row].tipo
        print(listaDispositivos[indexPath.row].tipo)
        tlCapacidad.text = listaDispositivos[indexPath.row].capacidad
        
        let format = NumberFormatter()
        format.numberStyle = .currency
        format.currencySymbol = "$"
        tlPrecio.text = format.string(for: listaDispositivos[indexPath.row].precio)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "idCell")!
        celda.textLabel?.text = listaDispositivos[indexPath.row].tipo

        return celda
    }
}

