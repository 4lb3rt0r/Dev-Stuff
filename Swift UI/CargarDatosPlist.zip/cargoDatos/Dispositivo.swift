//
//  Dispositivo.swift
//  cargoDatos
//
//  Created by Alumno on 08/09/22.
//

import UIKit

class Dispositivo : Codable {
    var tipo : String
    var capacidad : String
    var precio : Float
    var urlFoto : String
    
    init(tipo: String, capacidad : String, precio : Float, urlFoto : String ) {
        self.tipo = tipo
        self.capacidad = capacidad
        self.precio = precio
        self.urlFoto = urlFoto
    }
}
