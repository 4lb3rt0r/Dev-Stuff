//
//  ViewControllerPersona.swift
//  tableViews
//
//  Created by Alumno on 23/08/22.
//

import UIKit

class ViewControllerPersona: UIViewController {
    
    @IBOutlet weak var IDPersona: UILabel!
    
    var datoMostrar: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        IDPersona.text = datoMostrar

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
