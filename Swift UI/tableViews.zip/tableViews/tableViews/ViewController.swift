//
//  ViewController.swift
//  tableViews
//
//  Created by Alumno on 23/08/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    var listaPersonas = ["Alberto", "Jorge", "Felipe", "Ricardo"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "idCell" {
            let nombrePersona = segue.destination as! ViewControllerPersona
            var indexPath = tableView.indexPathForSelectedRow!
            nombrePersona.datoMostrar = listaPersonas[indexPath.row]
        }
    }

    func tableView(_ tableView:UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaPersonas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "idCell")!
        celda.textLabel?.text = listaPersonas[indexPath.row]
        celda.detailTextLabel?.text = "\(indexPath.row)" // muestra el renglon en el que esta el dato. Solo para el ejemplo
        celda.imageView?.image = UIImage(named: "user")
        return celda
    }
}

