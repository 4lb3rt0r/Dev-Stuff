//
//  Triangulo.swift
//  Tarea 1
//
//  Created by Alumno on 16/08/22.
//

import Foundation

class Triangulo {
    var lado1 : Float
    var lado2 : Float
    var lado3 : Float
    
    init(lado1: Float, lado2: Float, lado3: Float) {
        self.lado1 = lado1
        self.lado2 = lado2
        self.lado3 = lado3
    }
    
    func esTriangulo() -> Bool {
        if (lado1 + lado2) > lado3 && (lado1 + lado3) > lado2 && (lado2 + lado3) > lado1 {
            return true
        }
        else {
            return false
        }
    }
    
    func calArea() -> Double {
        let s = (lado1 + lado2 + lado3) / 2
        let area = Double(sqrt(Double(s * (s - lado1) * (s - lado2) * (s - lado3))))
        return area
    }
    
    func tipoTriangulo() -> String {
        if lado1 == lado2 && lado1 == lado3 && lado2 == lado3 {
            return "equilatero"
        }
        else if lado1 == lado2 || lado1 == lado3 || lado2 == lado3 {
            return "isosceles"
        }
        else if lado1 != lado2 && lado1 != lado3 && lado2 != lado3 {
            return "escaleno"
        }
        else {
            return ""
        }
    }
    
    func muestra () {
        print(lado1, lado2, lado3)
    }
}
