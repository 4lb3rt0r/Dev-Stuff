//
//  ViewController.swift
//  Tarea 1
//
//  Created by Alumno on 16/08/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var tfLadoX: UITextField!
    @IBOutlet weak var tfLadoY: UITextField!
    @IBOutlet weak var tfLadoZ: UITextField!
    @IBOutlet weak var tfResultado: UITextField!
    @IBOutlet weak var otTipo: UILabel!
    
    @IBOutlet weak var imgTriangulo: UIImageView!
    
    var t1 : Triangulo!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func calcula(_ sender: UIButton) {
        if let a = Float(tfLadoX.text!),
           let b = Float(tfLadoY.text!),
           let c = Float(tfLadoZ.text!) {
            if a > 0 && b > 0 && c > 0 {
                t1 = Triangulo(lado1: a, lado2: b, lado3: c)
                if t1.esTriangulo() {
                    let area = t1.calArea()
                    tfResultado.text = String(area)
                    let tTri = t1.tipoTriangulo()
                    if tTri == "equilatero" {
                        otTipo.text = "Tipo de Triángulo: Equilatero"
                        imgTriangulo.image = UIImage(named: tTri)
                    }
                    else if tTri == "isosceles" {
                        otTipo.text = "Tipo de Triángulo: Isósceles"
                        imgTriangulo.image = UIImage(named: tTri)
                    }
                    else {
                        otTipo.text = "Tipo de Triángulo: Escaleno"
                        imgTriangulo.image = UIImage(named: tTri)
                    }
                    
                    
                }
                else {
                    let alerta = UIAlertController(title: "Error", message: "Los valores ingresados no corresponden a un triángulo", preferredStyle: .alert)
                    let accion = UIAlertAction(title: "OK", style: .cancel)
                    alerta.addAction(accion)
                    present(alerta, animated: true)
                }
            }
            else {
                let alerta = UIAlertController(title: "Error", message: "Los valores ingresados no corresponden a un triángulo", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerta.addAction(accion)
                present(alerta, animated: true)
            }
        }
        else {
            let alerta = UIAlertController(title: "Error", message: "Debe haber valor numérico en los campos", preferredStyle: .alert)
            let accion = UIAlertAction(title: "OK", style: .cancel)
            alerta.addAction(accion)
            present(alerta, animated: true)
        }
    }
    
    @IBAction func quitaTeclado(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
}

