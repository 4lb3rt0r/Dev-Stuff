//
//  Tarea_1Tests.swift
//  Tarea 1Tests
//
//  Created by Alumno on 27/09/22.
//

import XCTest

@testable import Tarea_1

class Tarea_1Tests: XCTestCase {
    
    var sut1 : Triangulo!
    var sut2 : Triangulo!
    var sut3 : Triangulo!
    var sut4 : Triangulo!
    var sut5 : Triangulo!

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        sut1 = Triangulo(lado1: 7, lado2: 7, lado3: 7)
        sut2 = Triangulo(lado1: 3, lado2: 3, lado3: 5)
        sut3 = Triangulo(lado1: 7, lado2: 6, lado3: 5)
        sut4 = Triangulo(lado1: 2, lado2: 3, lado3: 4)
        sut5 = Triangulo(lado1: 11, lado2: 1, lado3: 45)
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        sut1 = nil
        sut2 = nil
        sut3 = nil
        sut4 = nil
        sut5 = nil
    }

    // Pruebas Unitarias:
    func testEquilatero() throws {
        XCTAssertEqual(sut1.tipoTriangulo(), "equilatero")
    }
    
    func testIsosceles() throws {
        XCTAssertEqual(sut2.tipoTriangulo(), "isosceles")
    }
    
    func testEscaleno() throws {
        XCTAssertEqual(sut3.tipoTriangulo(), "escaleno")
    }
    
    func testEsUnTriangulo() throws {
        XCTAssertTrue(sut4.esTriangulo())
    }
    
    func testNoEsUnTriangulo() throws {
        XCTAssertFalse(sut5.esTriangulo())
    }

}
